# Better Together Mobile App - Design System

## Overview

This document outlines the complete design system for the Better Together mobile application, providing a comprehensive reference for maintaining visual consistency and premium quality across all screens and features.

---

## Color Palette

### Primary Colors

The Better Together app uses a romantic, warm color scheme centered around pink and purple gradients that evoke feelings of love, connection, and warmth.

**Primary Gradient**
- **Pink**: `#FF6B9D` (Coral Pink)
- **Purple**: `#A855F7` (Vibrant Purple)
- **Usage**: Primary buttons, active states, highlights, branding elements

**Secondary Colors**
- **Coral**: `#FF8A80` - Used for Communication features
- **Lavender**: `#B794F6` - Used for Date Night features
- **Mint**: `#7DD3C0` - Used for Affection features
- **Peach**: `#FFB088` - Used for Gratitude features

### Neutral Colors

**Background**
- **White**: `#FFFFFF` - Primary background
- **Light Gray**: `#F8F9FA` - Secondary background, cards
- **Off-White**: `#FAFBFC` - Subtle backgrounds

**Text**
- **Black**: `#1A1A1A` - Primary text
- **Dark Gray**: `#4A4A4A` - Secondary text
- **Medium Gray**: `#8E8E93` - Tertiary text, placeholders
- **Light Gray**: `#C7C7CC` - Disabled text, borders

### Accent Colors

**Success**: `#34C759` - Confirmations, achievements
**Warning**: `#FF9500` - Alerts, important notices
**Error**: `#FF3B30` - Errors, destructive actions
**Info**: `#007AFF` - Information, links

---

## Typography

### Font Family

**Primary Font**: SF Pro Display (iOS) / Roboto (Android)
- Modern, clean, highly readable
- Excellent for both display and body text
- Native to each platform for optimal performance

### Font Sizes & Weights

**Display Text**
- **Hero Title**: 34pt, Bold (700) - Onboarding, major headings
- **Large Title**: 28pt, Bold (700) - Screen titles
- **Title 1**: 24pt, Semibold (600) - Section headers

**Body Text**
- **Title 2**: 20pt, Semibold (600) - Card titles, feature names
- **Body**: 17pt, Regular (400) - Primary content
- **Callout**: 16pt, Regular (400) - Secondary content
- **Subheadline**: 15pt, Regular (400) - Captions, metadata

**Small Text**
- **Footnote**: 13pt, Regular (400) - Timestamps, helper text
- **Caption**: 12pt, Regular (400) - Labels, tags

### Line Height

- **Display**: 1.2x font size
- **Body**: 1.5x font size
- **Small**: 1.4x font size

---

## Iconography

### Style Guidelines

**Design Principles**
- **Rounded**: All icons use rounded corners (2-3px radius)
- **Line Weight**: 2px stroke for consistency
- **Size**: 24x24px default, 20x20px small, 32x32px large
- **Style**: Outlined (not filled) for most icons, filled for active states

### Icon Library

**Navigation Icons**
- Home: House outline
- Calendar: Calendar with heart
- Messages: Chat bubble
- Profile: User silhouette

**Feature Icons**
- AI Coach: Chat bubble with dots
- Date Night: Calendar with heart
- Challenges: Trophy or flame
- Memories: Photo gallery
- Settings: Gear/cog

**Action Icons**
- Add: Plus in circle
- Edit: Pencil
- Delete: Trash can
- Share: Share arrow
- Send: Paper plane
- Back: Chevron left
- Forward: Chevron right

**Status Icons**
- Success: Checkmark in circle
- Warning: Exclamation in triangle
- Error: X in circle
- Info: i in circle

---

## Spacing System

### Base Unit: 8px

All spacing follows an 8-point grid system for consistency and rhythm.

**Spacing Scale**
- **XXS**: 4px - Tight spacing within components
- **XS**: 8px - Small gaps between related elements
- **SM**: 12px - Default spacing between elements
- **MD**: 16px - Standard padding, margins
- **LG**: 24px - Section spacing
- **XL**: 32px - Major section breaks
- **XXL**: 48px - Screen padding, large separations

**Component Padding**
- **Buttons**: 16px vertical, 24px horizontal
- **Cards**: 16px all sides
- **Screen Margins**: 20px left/right
- **List Items**: 16px vertical, 20px horizontal

---

## Components

### Buttons

**Primary Button**
- **Style**: Gradient background (pink to purple)
- **Text**: White, 17pt, Semibold
- **Padding**: 16px vertical, 32px horizontal
- **Border Radius**: 24px (fully rounded)
- **Shadow**: 0px 4px 12px rgba(168, 85, 247, 0.3)
- **States**: 
  - Default: Full opacity
  - Pressed: 90% opacity
  - Disabled: 40% opacity

**Secondary Button**
- **Style**: White background, gradient border (1px)
- **Text**: Gradient text (pink to purple), 17pt, Semibold
- **Padding**: 16px vertical, 32px horizontal
- **Border Radius**: 24px
- **Shadow**: 0px 2px 8px rgba(0, 0, 0, 0.08)

**Text Button**
- **Style**: No background
- **Text**: Purple (#A855F7), 17pt, Semibold
- **Padding**: 8px vertical, 16px horizontal
- **States**: Underline on press

### Cards

**Standard Card**
- **Background**: White
- **Border Radius**: 16px
- **Shadow**: 0px 2px 12px rgba(0, 0, 0, 0.08)
- **Padding**: 16px
- **Border**: None (shadow provides elevation)

**Feature Card** (Dashboard)
- **Background**: Gradient or solid color
- **Border Radius**: 20px
- **Shadow**: 0px 4px 16px rgba(0, 0, 0, 0.12)
- **Padding**: 20px
- **Icon**: 32x32px, white or colored
- **Text**: White, bold

**Challenge Card**
- **Background**: Solid gradient color
- **Border Radius**: 24px
- **Shadow**: 0px 6px 20px rgba(0, 0, 0, 0.15)
- **Padding**: 24px
- **3D Effect**: Subtle inner shadow for depth

### Input Fields

**Text Input**
- **Background**: White or light gray (#F8F9FA)
- **Border**: 1px solid #E5E5EA (default), gradient (focused)
- **Border Radius**: 12px
- **Padding**: 14px horizontal, 12px vertical
- **Text**: 17pt, Regular
- **Placeholder**: Medium gray (#8E8E93)

**Search Bar**
- **Background**: Light gray (#F8F9FA)
- **Border Radius**: 20px (fully rounded)
- **Icon**: Magnifying glass, left side
- **Padding**: 10px vertical, 16px horizontal
- **Text**: 17pt, Regular

### Navigation Bar

**Bottom Tab Bar**
- **Background**: White with blur effect
- **Height**: 80px (includes safe area)
- **Border**: 1px top border, light gray (#E5E5EA)
- **Icons**: 24x24px, gray (inactive), gradient (active)
- **Labels**: 11pt, gray (inactive), gradient (active)
- **Active Indicator**: Gradient color fill

**Top Navigation Bar**
- **Background**: Transparent or white
- **Height**: 44px (+ status bar)
- **Title**: 17pt, Semibold, centered
- **Back Button**: Chevron left, 24x24px
- **Action Buttons**: Icons, 24x24px

---

## Screen Layouts

### Standard Screen Structure

```
┌─────────────────────────┐
│   Navigation Bar        │ 44px + status bar
├─────────────────────────┤
│                         │
│   Content Area          │ Scrollable
│   (20px margins)        │
│                         │
├─────────────────────────┤
│   Bottom Tab Bar        │ 80px (if applicable)
└─────────────────────────┘
```

### Grid System

**Columns**: 12-column grid
**Gutter**: 16px between columns
**Margins**: 20px left/right

---

## Animations & Transitions

### Timing Functions

**Standard**: Ease-in-out (0.3s)
**Quick**: Ease-out (0.2s)
**Slow**: Ease-in-out (0.5s)

### Common Animations

**Page Transitions**
- **Push**: Slide from right (iOS), Fade + slide up (Android)
- **Modal**: Slide up from bottom
- **Duration**: 0.3s

**Button Press**
- **Scale**: 0.95x on press
- **Duration**: 0.1s
- **Timing**: Ease-out

**Card Tap**
- **Scale**: 0.98x on press
- **Shadow**: Reduce on press
- **Duration**: 0.15s

**Loading States**
- **Skeleton**: Shimmer effect, 1.5s loop
- **Spinner**: Rotate 360°, 1s loop

---

## Imagery

### Photo Guidelines

**Aspect Ratios**
- **Profile Photos**: 1:1 (square)
- **Memory Photos**: 4:3 or 16:9
- **Experience Cards**: 16:9
- **Hero Images**: 3:2

**Quality Standards**
- **Resolution**: Minimum 2x (Retina)
- **Format**: JPEG for photos, PNG for graphics
- **Compression**: 80% quality for photos
- **File Size**: < 500KB per image

### Illustrations

**Style**: Flat, minimalist, warm colors
**Usage**: Onboarding, empty states, error screens
**Color Palette**: Match brand colors (pink, purple, coral)

---

## Accessibility

### Color Contrast

**Text Contrast Ratios** (WCAG AA)
- **Normal Text**: Minimum 4.5:1
- **Large Text** (18pt+): Minimum 3:1
- **UI Components**: Minimum 3:1

### Touch Targets

**Minimum Size**: 44x44px (iOS), 48x48px (Android)
**Spacing**: Minimum 8px between interactive elements

### Text Accessibility

**Font Size**: Minimum 12pt for body text
**Line Height**: Minimum 1.5x for readability
**Dynamic Type**: Support iOS Dynamic Type, Android font scaling

---

## Dark Mode (Future)

### Color Adaptations

**Background**
- **Primary**: #1C1C1E (Dark gray)
- **Secondary**: #2C2C2E (Medium dark gray)
- **Tertiary**: #3A3A3C (Light dark gray)

**Text**
- **Primary**: #FFFFFF (White)
- **Secondary**: #EBEBF5 (Light gray)
- **Tertiary**: #ABABAB (Medium gray)

**Gradients**: Maintain same hues, adjust brightness for dark backgrounds

---

## Platform-Specific Guidelines

### iOS

**Navigation**: Use native iOS navigation patterns (back swipe, modal sheets)
**Haptics**: Provide haptic feedback for key interactions
**Safe Areas**: Respect notch and home indicator areas
**Blur Effects**: Use native blur for overlays

### Android

**Material Design**: Follow Material Design 3 guidelines
**Navigation**: Bottom navigation bar, floating action buttons
**Ripple Effects**: Use ripple for button presses
**Status Bar**: Adjust status bar color per screen

---

## Best Practices

### Visual Hierarchy

1. **Use size and weight** to establish importance
2. **Group related elements** with proximity and containers
3. **Use color sparingly** to draw attention to key actions
4. **Maintain consistency** across similar components

### Performance

1. **Optimize images** before including in app
2. **Use vector icons** (SVG) when possible
3. **Lazy load** images and heavy content
4. **Cache** frequently used assets

### User Experience

1. **Provide feedback** for all user actions
2. **Show loading states** for async operations
3. **Handle errors gracefully** with helpful messages
4. **Make navigation intuitive** with clear labels and icons

---

## Screen Inventory

### Completed Screens

1. **Onboarding Welcome** - Hero illustration, gradient background, CTA
2. **Partner Connection** - Invitation flow, email input, share link
3. **Home Dashboard** - Profile photos, streak counter, feature cards
4. **AI Coach Chat** - Message bubbles, input field, conversation UI
5. **Date Experiences Feed** - Scrollable cards, filters, booking CTA
6. **Intimacy Challenges** - Grid of challenge cards, categories, progress
7. **Calendar Scheduling** - Month view, availability overlay, suggested times
8. **Profile Settings** - User info, stats, settings list, premium badge
9. **Long-Distance Mode** - Time zones, map, connection features
10. **Memories Timeline** - Photo cards, milestones, vertical scroll

---

## Implementation Notes

### React Native Components

**UI Library**: React Native Paper or custom components
**Navigation**: React Navigation
**State Management**: React Context + tRPC
**Styling**: StyleSheet or Styled Components

### Code Organization

```
src/
├── components/
│   ├── buttons/
│   ├── cards/
│   ├── inputs/
│   └── navigation/
├── screens/
├── theme/
│   ├── colors.ts
│   ├── typography.ts
│   ├── spacing.ts
│   └── index.ts
└── assets/
    ├── icons/
    └── images/
```

---

## Version History

**Version 1.0** - November 2024
- Initial design system
- 10 core screens designed
- Complete component library
- Color palette and typography defined

---

## Resources

**Design Files**: Figma (link to be added)
**Icon Library**: Custom Better Together icons
**Inspiration**: Calm, Headspace, Airbnb, Instagram
**Design Tools**: Figma, Sketch, Adobe XD

---

**Maintained By**: Better Together Design Team  
**Last Updated**: November 2024  
**Contact**: design@better-together.app
